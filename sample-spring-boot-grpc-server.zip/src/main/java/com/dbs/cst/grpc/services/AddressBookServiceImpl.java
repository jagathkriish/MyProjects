package com.dbs.cst.grpc.services;

import java.util.ArrayList;
import java.util.List;

import org.jfairy.Fairy;

import com.dbs.cst.springboot.grpc.GRpcService;
import com.dbs.grpc.sample.AddressBook;
import com.dbs.grpc.sample.Person;
import com.dbs.grpc.sample.Person.PhoneNumber;
import com.dbs.grpc.sample.PersonId;
import com.dbs.grpc.sample.SaveStatus;
import com.dbs.grpc.sample.SetAndGetAddressesGrpc;

import io.grpc.stub.StreamObserver;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class AddressBookServiceImpl {

	@GRpcService
	public static class AddressBookService extends SetAndGetAddressesGrpc.SetAndGetAddressesImplBase {
		@Override
		public void savePerson(Person req, StreamObserver<SaveStatus> responseObserver) {
			log.info(req.toString());
			SaveStatus reply = SaveStatus.newBuilder().setStatus(true).build();
			responseObserver.onNext(reply);
			responseObserver.onCompleted();
		}

		@Override
		public void getPerson(PersonId req, StreamObserver<Person> responseObserver) {
			log.info(req.toString());
			List<PhoneNumber> noList = new ArrayList<>();
			noList.add(
					Person.PhoneNumber.newBuilder().setNumber("7207774725").setType(Person.PhoneType.MOBILE).build());

			noList.add(
					Person.PhoneNumber.newBuilder().setNumber("7207774726").setType(Person.PhoneType.MOBILE).build());

			noList.add(
					Person.PhoneNumber.newBuilder().setNumber("7207774727").setType(Person.PhoneType.MOBILE).build());

			noList.add(
					Person.PhoneNumber.newBuilder().setNumber("7207774728").setType(Person.PhoneType.MOBILE).build());

			Person reply = Person.newBuilder().setId(1).setName("jagath").setEmail("jagath143145@gmail.com")
					.addAllPhones(noList).build();

			log.info(reply.getPhones(0).getType().toString());
			log.info(reply.toString());
			responseObserver.onNext(reply);
			responseObserver.onCompleted();
		}

		@Override
		public void getAddressBook(PersonId req, StreamObserver<AddressBook> responseObserver) {

			List<Person> personList = new ArrayList<>();
			Fairy jf = Fairy.create();

			// Long phone = jf.baseProducer().randomBetween(7207774700L, 7207774799L);

			for (int i = 0; i < 1000; i++) {

				org.jfairy.producer.person.Person tmpPerson = jf.person();

				Person person = Person.newBuilder().setId(1).setName(tmpPerson.fullName()).setEmail(tmpPerson.email())
						.addPhones(Person.PhoneNumber.newBuilder().setNumber(tmpPerson.telephoneNumber())
								.setType(Person.PhoneType.MOBILE).build())
						.build();

				personList.add(person);

			}

			AddressBook reply = AddressBook.newBuilder().addAllPeople(personList).build();

			responseObserver.onNext(reply);
			responseObserver.onCompleted();

		}
	}
}

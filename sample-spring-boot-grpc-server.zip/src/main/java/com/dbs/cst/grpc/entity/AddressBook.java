package com.dbs.cst.grpc.entity;

public class AddressBook {

}

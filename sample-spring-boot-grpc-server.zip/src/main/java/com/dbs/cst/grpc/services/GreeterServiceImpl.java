package com.dbs.cst.grpc.services;

import com.dbs.cst.springboot.grpc.GRpcService;
import com.dbs.grpc.sample.GreeterGrpc;
import com.dbs.grpc.sample.HelloReply;
import com.dbs.grpc.sample.HelloRequest;

import io.grpc.stub.StreamObserver;

public class GreeterServiceImpl {
	@GRpcService()
	// @GRpcService(interceptors = { LogInterceptor.class })
    public static class GreeterService extends GreeterGrpc.GreeterImplBase {
		@Override
	    public void sayHello(HelloRequest req, StreamObserver<HelloReply> responseObserver) {
	      HelloReply reply = HelloReply.newBuilder().setMessage("Hello " + req.getName()).build();
	      responseObserver.onNext(reply);
	      responseObserver.onCompleted();
	    }
	    
	    @Override
	    public void sayGoodBye(HelloRequest req, StreamObserver<HelloReply> responseObserver) {
	      HelloReply reply = HelloReply.newBuilder().setMessage("Good Bye " + req.getName()).build();
	      responseObserver.onNext(reply);
	      responseObserver.onCompleted();
	    }
    }	
}

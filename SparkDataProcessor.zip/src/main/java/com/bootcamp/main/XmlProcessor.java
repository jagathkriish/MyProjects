package com.bootcamp.main;

import java.io.IOException;
import java.util.List;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.HColumnDescriptor;
import org.apache.hadoop.hbase.HTableDescriptor;
import org.apache.hadoop.hbase.client.HBaseAdmin;
import org.apache.hadoop.hbase.client.HTable;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.util.Bytes;
import org.apache.spark.SparkConf;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SQLContext;
import org.apache.spark.sql.SparkSession;

public class XmlProcessor {

	public static void main(String[] args) throws IOException, InterruptedException {
		// TODO Auto-generated method stub

		SparkConf conf = new SparkConf().setAppName("teamSpark").setMaster("local[2]");
		SparkSession spark = SparkSession.builder().config(conf).getOrCreate();

		spark.sparkContext().setLogLevel("Error");
		createTable();
		loadXmlData(spark.sqlContext(), args[0]);
		

	}

	private static void loadXmlData(SQLContext sqlContext, String path) throws IOException, InterruptedException {

		Long lval = 0L;

		HTable headerTable = getTable("tm1_HeaderTbl");
		HTable eventNotificationTable = getTable("tm1_EventNotificationDetails");
		HTable eventsTable = getTable("tm1_EventTable");

		Dataset<Row> df = sqlContext.read().format("com.databricks.spark.xml").option("rowTag", "publishEvent")
				.load(path);

		df.createOrReplaceTempView("sample");

		List<Row> headerList = sqlContext.sql(
				"select EventEnvelope.Header.Event.EventDateTime, EventEnvelope.Header.siid, EventEnvelope.Header.MsgUID, EventEnvelope.Header.RqClientId, EventEnvelope.Header.Ctry  from sample")
				.collectAsList();
		
		//TableMapReduceUtil.initTableReducerJob

		for (int i = 0; i < headerList.size(); i++) {
			
			if(i%100 == 0) {
				Thread.sleep(20);
			}
			insertDataToHbase(headerTable, "f1", lval++, "EventDateTime",
					((headerList.get(i).getString(0) == null) ? "" : headerList.get(i).getString(0)));
			insertDataToHbase(headerTable, "f1", lval++, "siid",
					((headerList.get(i).getString(1) == null) ? "" : headerList.get(i).getString(1)));
			insertDataToHbase(headerTable, "f1", lval++, "MsgUID",
					((headerList.get(i).getString(2) == null) ? "" : headerList.get(i).getString(2)));
			insertDataToHbase(headerTable, "f1", lval++, "RqClientId",
					((headerList.get(i).getString(3) == null) ? "" : headerList.get(i).getString(3)));
			insertDataToHbase(headerTable, "f1", lval++, "Ctry",
					((headerList.get(i).getString(4) == null) ? "" : headerList.get(i).getString(4)));
		}

		//headerTable.flushCommits();

		/*List<Row> eventNotificationList = sqlContext.sql(
				" select EventEnvelope.Body.EventNotificationDetails.LCIN, EventEnvelope.Body.EventNotificationDetails.CIF  from sample ")
				.collectAsList();

		for (int i = 0; i < eventNotificationList.size(); i++) {
			insertDataToHbase(eventsTable, "f1", lval++, "LCIN",
					((headerList.get(i).getString(0) == null) ? "" : headerList.get(i).getString(0)));
			insertDataToHbase(eventsTable, "f1", lval++, "CIF",
					((headerList.get(i).getString(1) == null) ? "" : headerList.get(i).getString(1)));
		}

		eventNotificationTable.close();

		List<Row> eventsList = sqlContext.sql(
				" select EventEnvelope.Header.Event.EventType, EventEnvelope.Header.Event.EventAction, EventEnvelope.Header.Event.EventDateTime  from sample ")
				.collectAsList();

		for (int i = 0; i < eventsList.size(); i++) {
			insertDataToHbase(eventNotificationTable, "f1", lval++, "EventType",
					((headerList.get(i).getString(0) == null) ? "" : headerList.get(i).getString(0)));
			insertDataToHbase(eventNotificationTable, "f1", lval++, "EventAction",
					((headerList.get(i).getString(1) == null) ? "" : headerList.get(i).getString(1)));
			insertDataToHbase(eventNotificationTable, "f1", lval++, "EventDateTime",
					((headerList.get(i).getString(1) == null) ? "" : headerList.get(i).getString(2)));
		}

		eventsTable.close();*/

	}

	private static void createTable() {

		try {

			Configuration c = HBaseConfiguration.create();
			HBaseAdmin ad = new HBaseAdmin(c);

			if (!ad.tableExists("tm1_HeaderTbl")) {
				HTableDescriptor htable = new HTableDescriptor("tm1_HeaderTbl");
				htable.addFamily(new HColumnDescriptor("f1"));
				ad.createTable(htable);
			}

			if (!ad.tableExists("tm1_EventNotificationDetails")) {
				HTableDescriptor htable = new HTableDescriptor("tm1_EventNotificationDetails");
				htable.addFamily(new HColumnDescriptor("f1"));
				ad.createTable(htable);
			}

			if (!ad.tableExists("tm1_EventTable")) {
				HTableDescriptor htable = new HTableDescriptor("tm1_EventTable");
				htable.addFamily(new HColumnDescriptor("f1"));
				ad.createTable(htable);
			}

		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	private static void insertDataToHbase(HTable table, String family, Long row_key, String col, String val)
			throws IOException {
		Put p = new Put(Bytes.toBytes(row_key));
		p.addColumn(Bytes.toBytes(family), Bytes.toBytes(col), Bytes.toBytes(val));
		table.put(p);
	}

	private static HTable getTable(String tbl) throws IOException {

		org.apache.hadoop.conf.Configuration config = HBaseConfiguration.create();
		HTable table = new HTable(config, tbl.getBytes());
		return table;
	}

}

package com.bootcamp.main;

import java.io.IOException;
import java.util.List;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.HColumnDescriptor;
import org.apache.hadoop.hbase.HTableDescriptor;
import org.apache.hadoop.hbase.TableName;
import org.apache.hadoop.hbase.client.HBaseAdmin;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.spark.JavaHBaseContext;
import org.apache.hadoop.hbase.util.Bytes;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.apache.yetus.audience.InterfaceAudience;

@InterfaceAudience.Private
public class XmlProcessor2 {

	static Long count = 0L;

	private XmlProcessor2() {
	};

	public static void main(String[] args) throws IOException, InterruptedException {

		SparkConf conf = new SparkConf().setAppName("teamSpark").setMaster("local[2]");
		SparkSession sparkSession = SparkSession.builder().config(conf).getOrCreate();
		JavaSparkContext jsc = new JavaSparkContext(conf);
		
		createTable();

		Dataset<Row> df = sparkSession.sqlContext().read().format("com.databricks.spark.xml")
				.option("rowTag", "publishEvent").load(args[0]);

		List<Row> headerList = df
				.select("EventEnvelope.Header.Event.EventDateTime", "EventEnvelope.Header.siid",
						"EventEnvelope.Header.MsgUID", "EventEnvelope.Header.RqClientId", "EventEnvelope.Header.Ctry")
				.collectAsList();

		JavaRDD<Row> rdd = jsc.parallelize(headerList);

		try {
			sparkSession.sparkContext().setLogLevel("Error");

			// createTable();

			String tableName = "tm1_HeaderTbl";

			Configuration config = HBaseConfiguration.create();

			JavaHBaseContext hbaseContext = new JavaHBaseContext(jsc, config);

			hbaseContext.bulkPut(rdd, TableName.valueOf(tableName), new PutFunction());

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			jsc.stop();
		}
	}

	public static class PutFunction implements Function<Row, Put> {

		private static final long serialVersionUID = 1L;

		@Override
		public Put call(Row v) throws Exception {
			Put put = new Put(Bytes.toBytes(count++));
			put.addColumn(Bytes.toBytes("f1"), Bytes.toBytes("EventDateTime"), Bytes.toBytes(v.getString(0)));
			return put;
		}

	}

	private static void createTable() {

		try {

			Configuration c = HBaseConfiguration.create();
			HBaseAdmin ad = new HBaseAdmin(c);

			if (!ad.tableExists("tm1_HeaderTbl")) {
				HTableDescriptor htable = new HTableDescriptor("tm1_HeaderTbl");
				htable.addFamily(new HColumnDescriptor("f1"));
				ad.createTable(htable);
			}

			if (!ad.tableExists("tm1_EventNotificationDetails")) {
				HTableDescriptor htable = new HTableDescriptor("tm1_EventNotificationDetails");
				htable.addFamily(new HColumnDescriptor("f1"));
				ad.createTable(htable);
			}

			if (!ad.tableExists("tm1_EventTable")) {
				HTableDescriptor htable = new HTableDescriptor("tm1_EventTable");
				htable.addFamily(new HColumnDescriptor("f1"));
				ad.createTable(htable);
			}

		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}

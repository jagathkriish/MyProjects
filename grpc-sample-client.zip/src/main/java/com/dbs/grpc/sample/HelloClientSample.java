package com.dbs.grpc.sample;

import java.util.logging.Logger;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;

public class HelloClientSample {
	private static final Logger logger = Logger.getLogger(HelloClientSample.class.getName());
	
	public static void main(String[] args) {
		ManagedChannel channel = ManagedChannelBuilder.forAddress("10.92.226.72", 8080)
		        .usePlaintext(true)
		        .build();
		
		GreeterGrpc.GreeterBlockingStub blockingStub = GreeterGrpc.newBlockingStub(channel);
		
		HelloRequest request = HelloRequest.newBuilder().setName("Venkatesh").build();
		
		HelloReply helloResponse = blockingStub.sayHello(request);

		    System.out.println(helloResponse);

		    channel.shutdown();
	}
	
}
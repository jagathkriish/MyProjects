package com.dbs.bootcamp;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Component;

import com.dbs.bootcamp.producer.Sender;

@Component
public class CommandLineRunners implements CommandLineRunner {

	@Autowired
	private Sender sender;

	@Value("${input-xml}")
	private Resource res;

	private static final String TOPIC = "bootcamp.team1";

	private static final Logger logger = LoggerFactory.getLogger(CommandLineRunners.class);

	@Override
	public void run(String... args) throws Exception {

		try (BufferedReader reader = new BufferedReader(new InputStreamReader(res.getInputStream()))) {
			
			String line = reader.readLine();
			while (line != null) {
				System.out.println(line);
				sender.send(TOPIC, line);
				line = reader.readLine();
			}

		} catch (IOException e) {
			e.printStackTrace();
		}

		logger.info(
				"Producer Application started with command-line arguments: {} \n",
				Arrays.toString(args));
	}
}

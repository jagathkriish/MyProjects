package com.dbs.cst.springboot.autoconfigure.grpc.client;

import java.util.List;

import io.grpc.Channel;
import io.grpc.ClientInterceptor;

/**
 * Maintained by jagathpathi from 16/06/18.
 */
public interface GrpcChannelFactory {

    Channel createChannel(String name);

    Channel createChannel(String name, List<ClientInterceptor> interceptors);
}

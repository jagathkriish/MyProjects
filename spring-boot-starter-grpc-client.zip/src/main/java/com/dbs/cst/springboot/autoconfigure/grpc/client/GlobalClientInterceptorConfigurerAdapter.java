package com.dbs.cst.springboot.autoconfigure.grpc.client;

/**
 * Maintained by jagathpathi from 16/06/18.
 */
public abstract class GlobalClientInterceptorConfigurerAdapter {

    public void addClientInterceptors(GlobalClientInterceptorRegistry registry) {

    }
}

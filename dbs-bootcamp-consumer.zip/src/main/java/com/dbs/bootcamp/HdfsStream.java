package com.dbs.bootcamp;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;

import org.apache.hadoop.fs.FSDataOutputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class HdfsStream {
	
	@Value("${hdfs-path}")
	private String hdfsPath;
	
	@Value("${hdfs-url}")
	private String hdfsUrl;
	
	@Bean
	public FSDataOutputStream hdfsstream() {
		FileSystem hdfs = null;
		FSDataOutputStream fos = null;
		org.apache.hadoop.conf.Configuration conf = new org.apache.hadoop.conf.Configuration();
		conf.set("fs.default.name", hdfsUrl);
		conf.set("fs.hdfs.impl", org.apache.hadoop.hdfs.DistributedFileSystem.class.getName());
		conf.set("fs.file.impl", org.apache.hadoop.fs.LocalFileSystem.class.getName());

		try {
			Path file = new Path(hdfsPath);
			hdfs = FileSystem.get(new URI(hdfsUrl), conf);
			if (hdfs.exists(file)) {
				hdfs.delete(file, true);
			}
			fos = hdfs.create(file);
			return fos;
		} catch (IOException e) {
			e.printStackTrace();
			return fos;
		} catch (URISyntaxException e) {
			e.printStackTrace();
			return fos;
		}
	}
}

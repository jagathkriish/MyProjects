package com.dbs.bootcamp;

import java.io.IOException;
import java.io.OutputStream;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.FileSystemResource;

@Configuration
public class FileAppendStream {

	@Value("${file-system-path}")
	private FileSystemResource outputFilePath;

	@Bean
	public OutputStream fileStream() {
		try {
			return outputFilePath.getOutputStream();
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
	}
}

package com.dbs.bootcamp.consumer;

import java.util.concurrent.CountDownLatch;

import org.apache.hadoop.fs.FSDataOutputStream;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;

public class Receiver {

	@Autowired
	FSDataOutputStream hdfsstream;

	// @Autowired
	// OutputStream fileStream;

	static long count = 0L;

	private static final Logger LOGGER = LoggerFactory.getLogger(Receiver.class);

	private CountDownLatch latch = new CountDownLatch(1);

	public CountDownLatch getLatch() {
		return latch;
	}

	@KafkaListener(topics = "${kafka.topic.bootcamp}")
	public void receive(String payload) {

		try {
			hdfsstream.writeBytes(payload + "\n");
			hdfsstream.flush();
			//hdfsstream.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

		/*
		 * try { fileStream.write(payload.getBytes());
		 * fileStream.write("\n".getBytes()); fileStream.flush(); } catch (Exception e)
		 * { e.printStackTrace(); }
		 */
		count++;
		LOGGER.info("received payload='{}'", payload);
		LOGGER.info("count was :" + count);
		latch.countDown();
	}
}

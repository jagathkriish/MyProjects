package com.dbs.bootcamp;

/**
 * Created by Owner on 2017. 03. 29..
 */
public class Word {
    private String word;

    public Word() {
    }

    public Word(String word) {
        this.word = word;
    }

    public void setWord(String word) {
        this.word = word;
    }

    public String getWord() {
        return word;
    }
}

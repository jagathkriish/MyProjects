package com.dbs.cst.springboot.grpc;

import io.grpc.ServerBuilder;

/**
 *  Maintained by Jagathpathi from 16/06/18.
 */
public class GRpcServerBuilderConfigurer {
    public void configure(ServerBuilder<?> serverBuilder){

    }
}

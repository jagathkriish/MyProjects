package com.dbs.cst.springboot.grpc.context;

import io.grpc.Server;
import org.springframework.context.ApplicationEvent;

public class GRpcServerInitializedEvent extends ApplicationEvent {

	private static final long serialVersionUID = 7368637628089083910L;
	/**
     * Create a new ApplicationEvent.
     *
     * @param source the object on which the event initially occurred (never {@code null})
     */
    public GRpcServerInitializedEvent(Server source) {
        super(source);
    }
    public Server getServer(){
        return (Server) getSource();
    }
}

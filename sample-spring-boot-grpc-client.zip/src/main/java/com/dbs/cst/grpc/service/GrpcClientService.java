package com.dbs.cst.grpc.service;

import org.springframework.stereotype.Service;

import com.dbs.cst.grpc.interceptors.LogGrpcInterceptor;
import com.dbs.cst.springboot.autoconfigure.grpc.client.GrpcClient;
import com.dbs.grpc.sample.GreeterGrpc;
import com.dbs.grpc.sample.HelloReply;
import com.dbs.grpc.sample.HelloRequest;

import io.grpc.Channel;

/**
 * User: Michael
 * Email: yidongnan@gmail.com
 * Date: 2016/11/8
 */
@Service
public class GrpcClientService {

    @GrpcClient(value = "local-grpc-server2", interceptors = { LogGrpcInterceptor.class })
    private Channel serverChannel;

    public String sendMessage(String name) {
    	GreeterGrpc.GreeterBlockingStub stub = GreeterGrpc.newBlockingStub(serverChannel);
        //SimpleGrpc.SimpleBlockingStub stub = SimpleGrpc.newBlockingStub(serverChannel);
        HelloReply response = stub.sayHello(HelloRequest.newBuilder().setName(name).build());
        return response.getMessage();
    }
}

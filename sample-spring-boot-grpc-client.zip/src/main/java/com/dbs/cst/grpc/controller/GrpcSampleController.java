package com.dbs.cst.grpc.controller;

import java.util.concurrent.ExecutionException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.dbs.cst.grpc.service.GrpcAddressBookService;
import com.dbs.cst.grpc.service.GrpcClientService;
import com.dbs.grpc.sample.AddressBook;
import com.dbs.grpc.sample.Person;
import com.dbs.grpc.sample.PersonId;
import com.google.common.util.concurrent.ListenableFuture;
import com.google.protobuf.InvalidProtocolBufferException;
import com.google.protobuf.util.JsonFormat;

@RestController
public class GrpcSampleController {

	@Autowired
	GrpcClientService clientService;

	@Autowired
	GrpcAddressBookService addressService;

	@GetMapping("/sayHello/{name}")
	public String sayHello(@PathVariable("name") String name) {
		return clientService.sendMessage(name);
	}

	@GetMapping("/savePerson")
	public boolean savePerson() {
		Person person = Person.newBuilder().setId(1).setName("jagath").setEmail("jagath143145@gmail.com")
				.addPhones(Person.PhoneNumber.newBuilder()
				        .setNumber("7207774725")
				        .setType(Person.PhoneType.MOBILE)).build();
		return addressService.savePerson(person);

	}

	@GetMapping("/getPerson/{id}")
	public String getPerson(@PathVariable("id") int id) throws InvalidProtocolBufferException, InterruptedException, ExecutionException {
		PersonId personId = PersonId.newBuilder().setPersonId(id).build();
		ListenableFuture<Person> person = addressService.getPersonById(personId);
		return JsonFormat.printer().print(person.get());
	}
	
	@GetMapping("/getAddressBook/{id}")
	public String getAddressBook(@PathVariable("id") int id) throws InvalidProtocolBufferException, InterruptedException, ExecutionException {
		PersonId personId = PersonId.newBuilder().setPersonId(id).build();
		Long start = System.currentTimeMillis();
		ListenableFuture<AddressBook> addBook = addressService.getAddressBookByPerson(personId);
		System.out.println("Time taken was :"+ (System.currentTimeMillis() - start));
		return JsonFormat.printer().print(addBook.get());
	}
}

package com.dbs.cst.grpc.service;

import org.springframework.stereotype.Service;

import com.dbs.cst.grpc.interceptors.LogGrpcInterceptor;
import com.dbs.cst.springboot.autoconfigure.grpc.client.GrpcClient;
import com.dbs.grpc.sample.AddressBook;
import com.dbs.grpc.sample.Person;
import com.dbs.grpc.sample.PersonId;
import com.dbs.grpc.sample.SetAndGetAddressesGrpc;
import com.google.common.util.concurrent.ListenableFuture;

import io.grpc.Channel;

@Service
public class GrpcAddressBookService {
	@GrpcClient(value = "local-grpc-server2", interceptors = { LogGrpcInterceptor.class })
    private Channel serverChannel;
	
	public boolean savePerson(Person person) {
		SetAndGetAddressesGrpc.SetAndGetAddressesBlockingStub stub = SetAndGetAddressesGrpc.newBlockingStub(serverChannel);
		return stub.savePerson(person).getStatus();
	}
	
	public ListenableFuture<Person> getPersonById(PersonId id) {
		SetAndGetAddressesGrpc.SetAndGetAddressesFutureStub stub = SetAndGetAddressesGrpc.newFutureStub(serverChannel);
		//SetAndGetAddressesGrpc.SetAndGetAddressesBlockingStub stub = SetAndGetAddressesGrpc.newBlockingStub(serverChannel);
		return stub.getPerson(id);
	}
	
	public ListenableFuture<AddressBook> getAddressBookByPerson(PersonId id) {
		SetAndGetAddressesGrpc.SetAndGetAddressesFutureStub stub = SetAndGetAddressesGrpc.newFutureStub(serverChannel);
		return stub.getAddressBook(id);
	}
}
